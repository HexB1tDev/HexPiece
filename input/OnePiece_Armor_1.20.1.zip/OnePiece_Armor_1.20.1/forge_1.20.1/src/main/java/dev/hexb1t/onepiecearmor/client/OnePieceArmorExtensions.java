package dev.hexb1t.onepiecearmor.client;

import java.util.HashMap;
import java.util.Map;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.Model;
import net.minecraft.client.player.AbstractClientPlayer;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.client.extensions.common.IClientItemExtensions;

/** Instantiate this only from ArmorItem.initializeClient. Both fits are cached independently. */
public final class OnePieceArmorExtensions implements IClientItemExtensions {
    private final OnePieceArmorModel.Style style;
    private final Map<Boolean, OnePieceArmorModel> models = new HashMap<>();

    public OnePieceArmorExtensions(OnePieceArmorModel.Style style) {
        this.style = style;
    }

    @Override
    public Model getGenericArmorModel(LivingEntity entity, ItemStack stack,
                                      EquipmentSlot slot, HumanoidModel<?> original) {
        boolean slim = entity instanceof AbstractClientPlayer player && "slim".equals(player.getModelName());
        OnePieceArmorModel model = models.computeIfAbsent(slim, fit -> new OnePieceArmorModel(style, fit));
        model.copyPoseFrom(original, slot);
        return model;
    }
}
