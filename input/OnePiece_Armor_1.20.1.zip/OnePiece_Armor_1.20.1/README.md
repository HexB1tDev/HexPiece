# One Piece wearable models — Minecraft 1.20.1

Actual wearable geometry and textures based on the supplied four-design reference.

| Design | Armor slots | Editable variants |
|---|---|---|
| Marine outfit | Cap: head; shirt: chest; trousers: legs; boots: feet | Steve 4-pixel arms / Alex 3-pixel arms |
| Admiral coat | Chest, including both leg-following tails | Steve / Alex |
| Straw hat | Head | Shared fit: the head is identical on both skins |
| Blackbeard coat | Chest, including both leg-following tails | Steve / Alex |

## Contents

`blockbench/` — seven editable, rigged `.bbmodel` files with embedded textures. Open directly in Blockbench's Modded Entity format. The mannequin shown in the previews is not part of these models.

`forge_1.20.1/src/main/resources/` — four PNG texture atlases, 1024 × 1024. Logical UV size is **256 × 256**. Keep the Java texture dimensions at 256: the four-times-larger PNGs provide extra detail without changing UV placement.

`forge_1.20.1/src/main/java/` — ready-to-integrate Mojang-mapped Forge 47.x model and item-rendering adapter. Requires Java 17 and the host mod's Forge 1.20.1 environment. No GeckoLib or other animation library is needed.

`INTEGRATION.md` — exact item hooks and texture paths.

## Movement and fit

Headwear uses the head bone. Shirt, buttons, tie and collar use the torso. Sleeves, cuffs and shoulder epaulettes use their respective arm bones. Each lower coat half uses its respective leg bone, including its lining, buttons and trim. Walking, crouching, attacks, riding and swimming therefore use the pose already supplied by Minecraft; the adapter does not replace the player's animation.

Steve and Alex use separate sleeve geometry, cuffs and shoulder details, with automatic skin-model selection. The adapter deliberately renders coat leg parts even though a coat occupies the chest slot. Marine pieces can be equipped independently. Hats and coats preserve the player's skin and do not add a face, hair, shirt or trousers.

The coat motion is bone-driven, with a central split; this is not a cloth simulation. Minecraft's normal rigid limbs are used. Custom animation mods must supply their pose to the armor model, as they do for other HumanoidModel armor. First-person hand rendering is not changed by these assets.

## Validation

The previews are rendered from the delivered cube geometry, atlas UVs and bone hierarchy. Standard and slim geometry, per-slot part visibility, UV bounds and representative movement poses are checked. Java sources are syntax-checked with the Java compiler parser. This is an asset/integration pack, not a compiled mod or a vanilla resource pack. The Forge adapter has not been compiled in a full Forge project or tested inside Minecraft; validate it in the host mod before release.
