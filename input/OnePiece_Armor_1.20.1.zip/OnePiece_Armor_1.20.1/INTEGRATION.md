# Forge 1.20.1 integration

Copy the two files under `forge_1.20.1/src/main/java` and the `assets/hexpiece` directory into the host mod's matching source folders. They use Forge 47.x and official Mojang mappings. Keep the namespace `hexpiece` or update the texture paths below if you rename it.

Each wearable must be an `ArmorItem` registered with the correct `ArmorItem.Type`. Item registration, attributes, recipes and icons belong to the host mod and are intentionally not included.

In the relevant ArmorItem subclass, connect its client extension:

```java
@Override
public void initializeClient(java.util.function.Consumer<net.minecraftforge.client.extensions.common.IClientItemExtensions> consumer) {
    consumer.accept(new dev.hexb1t.onepiecearmor.client.OnePieceArmorExtensions(
        dev.hexb1t.onepiecearmor.client.OnePieceArmorModel.Style.ADMIRAL));
}

@Override
public String getArmorTexture(net.minecraft.world.item.ItemStack stack,
        net.minecraft.world.entity.Entity entity,
        net.minecraft.world.entity.EquipmentSlot slot, String type) {
    return "hexpiece:textures/models/armor/admiral_coat.png";
}
```

Use the corresponding style and texture for each item:

| Item | ArmorItem.Type | Style | Texture path after `hexpiece:textures/models/armor/` |
|---|---|---|---|
| Marine cap | HELMET | MARINE | marine_outfit.png |
| Marine shirt | CHESTPLATE | MARINE | marine_outfit.png |
| Marine trousers | LEGGINGS | MARINE | marine_outfit.png |
| Marine boots | BOOTS | MARINE | marine_outfit.png |
| Admiral coat | CHESTPLATE | ADMIRAL | admiral_coat.png |
| Straw hat | HELMET | STRAW_HAT | straw_hat.png |
| Blackbeard coat | CHESTPLATE | BLACKBEARD | blackbeard_coat.png |

The client extension overrides `getGenericArmorModel` so it can copy every needed bone transform and restore coat-tail visibility after the vanilla chest-slot mask. Do not apply the vanilla chest-only mask again after this hook. The geometry is baked once for each fit, then reused. Only the fit is cached; the current entity pose and equipment slot are copied every render.

Keep the `client` classes referenced inside `initializeClient`, not in common static initializers or server-side constructors. Do not add a standalone armor layer on top of this item hook, which would draw the model twice. The generated model classes contain all geometry and require no separate layer-registration event.

For non-player humanoids the adapter uses the standard fit. To support a custom narrow-armed NPC, extend the `slim` detection in `OnePieceArmorExtensions` to match that NPC model.

Upstream API reference: https://github.com/MinecraftForge/MinecraftForge/blob/1.20.1/src/main/java/net/minecraftforge/client/extensions/common/IClientItemExtensions.java
